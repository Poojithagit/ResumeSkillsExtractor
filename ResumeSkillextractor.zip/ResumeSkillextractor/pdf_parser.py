import re
import os
import PyPDF2
import spacy
from typing import List, Dict, Optional, Tuple, Union, Any
from collections import defaultdict
import io
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load the spaCy model
try:
    # Try to load the model directly
    import en_core_web_sm
    nlp = en_core_web_sm.load()
except ImportError:
    # Fallback to spacy.load()
    import spacy
    try:
        nlp = spacy.load('en_core_web_sm')
    except OSError:
        # If model is not found, download it
        import subprocess
        import sys
        subprocess.check_call([sys.executable, "-m", "spacy", "download", "en_core_web_sm"])
        nlp = spacy.load('en_core_web_sm')

def extract_text_from_pdf(pdf_path: str) -> str:
    """Extracts text from a PDF using PyPDF2, preserving line breaks and layout as much as possible."""
    if not os.path.exists(pdf_path):
        logger.error(f"PDF file not found: {pdf_path}")
        return ""
    try:
        text = ""
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    # Do not collapse whitespace or line breaks, just strip trailing whitespace
                    lines = [line.rstrip() for line in page_text.splitlines()]
                    text += '\n'.join(lines) + "\n\n"
        # Minimal cleanup: remove control chars except newlines, collapse >2 newlines
        text = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()
    except PyPDF2.errors.PdfReadError as e:
        logger.error(f"Error reading PDF file: {str(e)}")
        return ""
    except Exception as e:
        logger.error(f"Unexpected error extracting text from PDF: {str(e)}")
        return ""

# A sample list of skills - this can be expanded significantly or loaded from a file
SKILL_KEYWORDS = [
    "Python", "Java", "C++", "C#", "JavaScript", "HTML", "CSS", "SQL", "NoSQL",
    "React", "Angular", "Vue.js", "Node.js", "Django", "Flask", "Spring Boot",
    "Machine Learning", "Deep Learning", "Data Analysis", "Data Science", "NLP",
    "AWS", "Azure", "Google Cloud", "Docker", "Kubernetes", "Git", "Agile", "Scrum",
    "Project Management", "Communication", "Teamwork", "Problem Solving",
    "TensorFlow", "PyTorch", "Pandas", "NumPy", "Scikit-learn", "Excel",
    "Power BI", "Tableau", "Linux", "Unix", "Shell Scripting", "Cybersecurity"
]


def extract_skills_from_text(text: str) -> List[str]:
    """
    Extracts skills from the resume text with the following priority:
    1. From the 'Skills' section (if found)
    2. From work experience and projects
    3. Fallback to SKILL_KEYWORDS matching
    """
    if not text:
        return []
    
    all_skills = set()
    text_lower = text.lower()  # Pre-compute lowercase text once
    
    # 1. Extract from 'Skills' section first (highest priority)
    try:
        pattern = re.compile(
            r'(?:^|\n)\s*(?:Technical[\s-]*Skills?|Skills?)[\s:]*\n([\s\S]+?)(?=\n\s*\n|\n[A-Z][A-Za-z ]{2,}\n|$)',
            re.IGNORECASE
        )
        match = pattern.search(text)
        if match:
            skills_section = match.group(1).strip()
            # Split by common delimiters and clean up
            raw_skills = re.split(r'[\n,;•\-\|]', skills_section)
            for skill in raw_skills:
                skill = skill.strip()
                if skill and len(skill) >= 2:  # At least 2 characters
                    # Remove any trailing punctuation
                    skill = re.sub(r'[^\w\s-]+$', '', skill)
                    if skill:  # Check if anything remains after cleaning
                        all_skills.add(skill)
    except Exception as e:
        print(f"Error extracting skills section: {e}")
    
    # 2. Extract from work experience and projects
    try:
        # Pre-compile patterns for better performance
        # Fix: Remove variable-width look-behind, use a more robust pattern
        bullet_pattern = re.compile(r'^[\s\t]*[•\-]\s*([^•\n]+)', re.IGNORECASE | re.MULTILINE)
        tech_pattern = re.compile(r'(?:Technolog(?:y|ies)|Tools?)[\s:]+([^\n]+)', re.IGNORECASE)
        
        # Extract work experience section
        work_exp_pattern = re.compile(
            r'(?:Work[\s-]*Experience|Experience|Professional[\s-]*Experience)[\s:]*\n([\s\S]+?)(?=\n\s*\n\s*(?:Education|Projects?|Skills?|$))',
            re.IGNORECASE
        )
        work_match = work_exp_pattern.search(text)
        if work_match:
            work_exp_section = work_match.group(1)
            # Extract job descriptions
            job_descriptions = bullet_pattern.findall(work_exp_section)
            for desc in job_descriptions:
                for skill in SKILL_KEYWORDS:
                    if skill.lower() in text_lower:
                        all_skills.add(skill)
        
        # Extract projects section
        projects_pattern = re.compile(
            r'(?:Projects?|Personal[\s-]*Projects?)[\s:]*\n([\s\S]+?)(?=\n\s*\n\s*(?:Skills?|Education|Work[\s-]*Experience|$))',
            re.IGNORECASE
        )
        projects_match = projects_pattern.search(text)
        if projects_match:
            projects_section = projects_match.group(1)
            # Extract project descriptions
            project_descriptions = bullet_pattern.findall(projects_section)
            for desc in project_descriptions:
                # Look for technologies used (e.g., "Technologies: Python, Django")
                tech_match = tech_pattern.search(desc)
                if tech_match:
                    techs = re.split(r'[,\s;•\-]', tech_match.group(1))
                    for tech in techs:
                        tech = tech.strip()
                        if tech and len(tech) >= 2 and any(c.isalpha() for c in tech):
                            all_skills.add(tech)
                # Also check for skills in the description
                for skill in SKILL_KEYWORDS:
                    if skill.lower() in text_lower:
                        all_skills.add(skill)
    except Exception as e:
        print(f"Error extracting skills from work/projects: {e}")
    
    # 3. Fallback: If no skills found yet, use SKILL_KEYWORDS matching
    if not all_skills:
        for skill in SKILL_KEYWORDS:
            if skill.lower() in text_lower:
                all_skills.add(skill)
    
    return sorted(all_skills)

def extract_skills_nlp(text):
    """
    Extract probable skill phrases using spaCy NLP from given text.
    Returns a list of skill-like noun phrases and proper nouns, filtered to remove generic or non-skill phrases.
    """
    if not text or nlp is None:
        return []
    doc = nlp(text)
    skill_candidates = set()
    # Blacklist of generic/irrelevant phrases (lowercase)
    blacklist = set([
        'the model', 'the year', 'the web', 'the chatbot', 'the classification model',
        'the adam optimizer', 'the dice score', 'the pytorch framework', 'the institute nso fitness team',
        'the organization’s online presence', 'the project', 'the institute hiking group',
        'the organization', 'the company', 'the team', 'the data', 'the features', 'the results',
        'the precision', 'the outreach', 'the performance', 'the skills', 'the impact', 'the test data',
        'the stock prices', 'the scalability', 'the strategic partnerships', 'the strategic thinking',
        'the student engagement', 'the team-building skills', 'the social impact', 'the queries',
        'the medical documents', 'the medical queries', 'the normalizing', 'the normalizing features',
        'project outreach', 'query handling', 'socio-economic upliftment', 'scalability and robust performance',
        'medical documents', 'medical queries', 'normalizing', 'normalizing features', 'test data',
        'stock prices', 'strategic partnerships', 'strategic thinking', 'student engagement', 'team-building skills',
        'social impact', 'socio-economic upliftment', 'project outreach', 'query handling', 'precision', 'outreach',
        'performance', 'impact', 'results', 'features', 'data', 'company', 'organization', 'project', 'team', 'web',
        'year', 'skills', 'queries', 'model', 'score', 'optimizer', 'framework', 'institute', 'presence', 'partnerships',
    ])
    stopwords = set(['the', 'a', 'an', 'of', 'and', 'for', 'to', 'with', 'in', 'on', 'at', 'by', 'from', 'as', 'is', 'are'])
    # Extract noun chunks (phrases)
    for chunk in doc.noun_chunks:
        phrase = chunk.text.strip()
        phrase_lower = phrase.lower()
        if 2 <= len(phrase) <= 50 and len(phrase.split()) <= 5:
            # Filter: skip if starts with stopword or is in blacklist
            if phrase_lower in blacklist:
                continue
            if phrase_lower.split()[0] in stopwords:
                continue
            if phrase_lower.endswith('group') or phrase_lower.endswith('team') or phrase_lower.endswith('organization'):
                continue
            # Optionally, only keep if contains a word from SKILL_KEYWORDS
            if not any(skill.lower() in phrase_lower for skill in SKILL_KEYWORDS):
                continue
            skill_candidates.add(phrase)
    # Extract proper nouns (single or multi-word)
    current_propn = []
    for token in doc:
        if token.pos_ == 'PROPN':
            current_propn.append(token.text)
        else:
            if current_propn:
                phrase = ' '.join(current_propn)
                phrase_lower = phrase.lower()
                if len(phrase) > 1 and phrase_lower not in blacklist and phrase_lower.split()[0] not in stopwords:
                    if not any(skill.lower() in phrase_lower for skill in SKILL_KEYWORDS):
                        current_propn = []
                        continue
                    skill_candidates.add(phrase)
                current_propn = []
    if current_propn:
        phrase = ' '.join(current_propn)
        phrase_lower = phrase.lower()
        if len(phrase) > 1 and phrase_lower not in blacklist and phrase_lower.split()[0] not in stopwords:
            if any(skill.lower() in phrase_lower for skill in SKILL_KEYWORDS):
                skill_candidates.add(phrase)
    # Remove duplicates and return sorted
    return sorted(skill_candidates)



def extract_email(text):
    """Extracts email address from text using regex."""
    if not text:
        return None
    # Basic email regex, can be improved
    match = re.search(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text)
    return match.group(0) if match else None

def extract_phone(text):
    """Extracts phone number from text using regex. Catches common US formats."""
    if not text:
        return None
    # Regex for various phone formats (e.g., (123) 456-7890, 123-456-7890, 123.456.7890, 123 456 7890)
    # This regex is a common example and might need adjustment for international numbers or specific formats.
    match = re.search(r'\(?\b[2-9][0-9]{2}\)?[-. ]?[2-9][0-9]{2}[-. ]?[0-9]{4}\b', text)
    return match.group(0) if match else None

def extract_name(text):
    if not text:
        return None
    
    lines = text.split('\n')
    for line in lines:
        stripped_line = line.strip()
        if stripped_line:
            words = stripped_line.split()
            if len(words) >= 2:
                return ' '.join(words[:2])
            elif len(words) == 1:
                return words[0]
    """Extracts work experience sections with company names and roles.
    
    Args:
        text (str): The text content of the resume
        
    Returns:
        list: A list of dictionaries containing 'company', 'role', 'dates', and 'description' for each position
    """
    if not text:
        return []
    
    # Common section headers for work experience
    work_exp_headers = [
        r'work\s*experience',
        r'employment\s*history',
        r'professional\s*experience',
        r'experience',
        r'career\s*history',
        r'work history',
        r'professional background',
        r'employment record',
        r'career summary',
        r'employment background'
    ]
    
    # Common section endings
    section_endings = [
        r'education',
        r'skills',
        r'projects',
        r'certifications',
        r'publications',
        r'volunteer',
        r'references',
        r'\n\s*\n'
    ]
    
    # Try to find the work experience section
    work_exp_section = None
    
    for header in work_exp_headers:
        # Look for section header followed by content until next section
        pattern = rf'(?i){header}\s*[\n\-~=*_]*\s*\n(.*?)(?=\n\s*\n(?:{"|".join(section_endings)}))'
        match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
        if match:
            work_exp_section = match.group(1).strip()
            break
    
    if not work_exp_section:
        # If no section header found, try to extract from the whole text
        work_exp_section = text
    
    # Common date patterns
    date_patterns = [
        r'(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*\d{4}\s*[-–—]\s*(?:Present|Now|Current|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*\d{4})',
        r'\d{1,2}/\d{4}\s*[-–—]\s*(?:Present|Now|Current|\d{1,2}/\d{4})',
        r'\d{4}\s*[-–—]\s*(?:Present|Now|Current|\d{4})',
        r'(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*\d{4}\s*[-–—]\s*\d{4}',
        r'\d{4}\s*[-–—]\s*\d{4}'
    ]
    
def extract_work_experience(text: str) -> list:
    """Extracts work experience sections with company names and roles.
    
    Args:
        text (str): The text content of the resume
        
    Returns:
        list: A list of dictionaries containing 'company', 'role', 'dates', and 'description' for each position
    """
    if not text:
        return []
    
    # Common section headers for work experience
    work_exp_headers = [
        r'work\s*experience',
        r'employment\s*history',
        r'professional\s*experience',
        r'experience',
        r'career\s*history',
        r'work history',
        r'professional background',
        r'employment record',
        r'career summary',
        r'employment background'
    ]
    
    # Common section endings
    section_endings = [
        r'education',
        r'skills',
        r'projects',
        r'certifications',
        r'publications',
        r'volunteer',
        r'references',
        r'\n\s*\n'
    ]
    
    # Try to find the work experience section
    work_exp_section = None
    
    for header in work_exp_headers:
        # Look for section header followed by content until next section
        pattern = rf'(?i){header}\s*[\n\-~=*_]*\s*\n(.*?)(?=\n\s*\n(?:{"|".join(section_endings)}))'
        match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
        if match:
            work_exp_section = match.group(1).strip()
            break
    
    if not work_exp_section:
        # If no section header found, try to extract from the whole text
        work_exp_section = text
    
    # Common date patterns
    date_patterns = [
        r'(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*\d{4}\s*[-–—]\s*(?:Present|Now|Current|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*\d{4})',
        r'\d{1,2}/\d{4}\s*[-–—]\s*(?:Present|Now|Current|\d{1,2}/\d{4})',
        r'\d{4}\s*[-–—]\s*(?:Present|Now|Current|\d{4})',
        r'(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*\d{4}\s*[-–—]\s*\d{4}',
        r'\d{4}\s*[-–—]\s*\d{4}'
    ]
    
    # Common position patterns - more flexible matching
    position_patterns = [
        # Pattern 1: Company - Role (Date)
        r'^(?P<company>[^\n]+?)\s*[-–—]\s*(?P<role>[^\n(]+?)\s*(?:\((?P<dates>[^)]+)\))?\s*\n(?P<description>(?:.+\n?)+)$',
        # Pattern 2: Role at Company (Date)
        r'^(?P<role>[^\n]+?)\s+(?:at|@|\||:)\s+(?P<company>[^\n(]+?)\s*(?:\((?P<dates>[^)]+)\))?\s*\n(?P<description>(?:.+\n?)+)$',
        # Pattern 3: Just dates and description
        r'^(?P<dates>(?:(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[\s,]*\d{4}|\d{1,2}[/\-\.]\d{4}|(?:19|20)\d{2})[^\n]*?)(?:\s*[-–—]\s*(?P<end_date>present|now|current|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[\s,]*\d{4}|\d{1,2}[/\-\.]\d{4}|(?:19|20)\d{2}))?\s*\n(?P<description>(?:.+\n?)+)$',
        # Pattern 4: Company on first line, role on second line
        r'^(?P<company>[^\n]+?)\s*\n\s*(?P<role>[^\n(]+?)(?:\s*\((?P<dates>[^)]+)\))?\s*\n(?P<description>(?:.+\n?)+)$',
        # Pattern 5: Just a block of text with dates
        r'^(?P<description>(?:(?:(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[\s,]*\d{4}|\d{1,2}[/\-\.]\d{4}|(?:19|20)\d{2}).*?\n)+.*?)$'
    ]
    
    # Split into potential position blocks
    position_blocks = re.split(r'\n\s*\n', work_exp_section)
    positions = []
    
    for block in position_blocks:
        block = block.strip()
        if not block or len(block.split()) < 3:  # Skip very short blocks
            continue
            
        # Skip if this looks like a section header or other non-position block
        block_lower = block.lower()
        if any(header in block_lower for header in 
              ['education', 'skills', 'projects', 'certifications', 'references']):
            continue
            
        # Try to extract position details with multiple patterns
        position = {}
        
        # First, try to extract dates
        for date_pattern in date_patterns:
            date_match = re.search(date_pattern, block, re.IGNORECASE)
            if date_match:
                position['dates'] = date_match.group(0).strip()
                # Remove dates from block to avoid interference with other patterns
                block = re.sub(re.escape(position['dates']), '', block)
                break
        
        # Try different position patterns
        for pattern in position_patterns:
            match = re.search(pattern, block, re.IGNORECASE | re.DOTALL)
            if match:
                position.update({k: v.strip() for k, v in match.groupdict().items() if v})
                break
        
        # If we have a description, clean it up
        if 'description' in position:
            # Remove any remaining role/company/date lines from description
            desc_lines = position['description'].split('\n')
            cleaned_lines = []
            
            for line in desc_lines:
                line = line.strip()
                if not line:
                    continue
                    
                # Skip lines that look like they contain role/company/date
                if (('role' in position and position['role'] and 
                     position['role'].lower() in line.lower()) or
                    ('company' in position and position['company'] and 
                     position['company'].lower() in line.lower()) or
                    ('dates' in position and position['dates'] and 
                     any(d.lower() in line.lower() for d in position['dates'].split() if len(d) > 3))):
                    continue
                    
                cleaned_lines.append(line)
            
            position['description'] = '\n'.join(cleaned_lines)
        
        # Add to positions if we have enough information
        if position and ('role' in position or 'company' in position or 'description' in position):
            # Clean up the position data
            position = {k: v for k, v in position.items() if v and v.strip()}
            
            # If we have dates but no role/company, try to extract from the dates line
            if 'dates' in position and ('role' not in position or 'company' not in position):
                date_line = position['dates']
                # Look for role/company patterns in the date line
                role_company = re.search(r'^(.+?)\s*[-–—]\s*(.+?)\s*$', date_line)
                if role_company:
                    if 'role' not in position:
                        position['role'] = role_company.group(1).strip()
                    if 'company' not in position:
                        position['company'] = role_company.group(2).strip()
            
            positions.append(position)
    
    return positions





def extract_self_contained_project(block: str) -> dict:
    """Extract project information from a well-formatted project block."""
    lines = [line.strip() for line in block.split('\n') if line.strip()]
    if not lines:
        return None
    
    project = {}
    
    # First line is the project name
    project['name'] = lines[0]
    
    # Look for structured sections
    current_section = None
    description_lines = []
    
    for line in lines[1:]:
        # Check for section headers
        section_match = re.match(
            r'^(?:\s*[-•*]?\s*)?(Technologies?|Tools?|Stack|Features?|Responsibilities?|Achievements?|Results?|Description|Details?|Links?|URLs?)\s*[:\-]?\s*$',
            line, re.IGNORECASE
        )
        
        if section_match:
            # Save previous section
            if current_section == 'description' and description_lines:
                project['description'] = '\n'.join(description_lines)
                description_lines = []
            
            current_section = section_match.group(1).lower()
            continue
        
        # Process line based on current section
        if current_section in ['technologies', 'technology', 'tools', 'tool', 'stack']:
            if 'technologies' not in project:
                project['technologies'] = []
            techs = [t.strip() for t in re.split(r'[,\s/;]', line) if t.strip()]
            project['technologies'].extend(techs)
        elif current_section in ['responsibilities', 'responsibility']:
            if 'responsibilities' not in project:
                project['responsibilities'] = []
            project['responsibilities'].append(line.strip())
        elif current_section in ['achievements', 'results']:
            if 'achievements' not in project:
                project['achievements'] = []
            project['achievements'].append(line.strip())
        elif current_section in ['links', 'url', 'urls']:
            urls = re.findall(r'https?://[^\s\n)]+', line)
            if urls:
                if 'urls' not in project:
                    project['urls'] = []
                project['urls'].extend(urls)
        else:
            description_lines.append(line.strip())
    
    # Save the last section if it was a description
    if current_section == 'description' and description_lines:
        project['description'] = '\n'.join(description_lines)
    elif not current_section and description_lines:
        project['description'] = '\n'.join(description_lines)
    
    return project if len(project) > 1 else None


def parse_project_title_line(line: str) -> dict:
    """Parse the title line of a project to extract name, technologies, and date."""
    project = {}
    
    # Common patterns for project title lines
    patterns = [
        # Pattern 1: Project Name (Technologies) - Date
        r'^(?P<name>[^(\n]+?)(?:\s*\((?P<technologies>[^)]+)\))?(?:\s*[-–—]\s*(?P<date>[^\n]+))?$',
        # Pattern 2: Project Name - Role - Date
        r'^(?P<name>[^\n-–—]+?)(?:\s*[-–—]\s*(?P<role>[^\n-–—]+?))?(?:\s*[-–—]\s*(?P<date>[^\n]+))?$',
        # Pattern 3: Just project name
        r'^(?P<name>[^\n]+?)$'
    ]
    
    for pattern in patterns:
        match = re.match(pattern, line, re.IGNORECASE)
        if match:
            groups = match.groupdict()
            if 'name' in groups and groups['name']:
                project['name'] = groups['name'].strip()
            if 'technologies' in groups and groups['technologies']:
                techs = [t.strip() for t in re.split(r'[,\s/;]', groups['technologies']) if t.strip()]
                if techs:
                    project['technologies'] = techs
            if 'date' in groups and groups['date']:
                project['date'] = groups['date'].strip()
            if 'role' in groups and groups['role']:
                project['role'] = groups['role'].strip()
            break
    
    return project


def clean_project_data(project: dict) -> dict:
    """Clean and standardize the project data."""
    if not isinstance(project, dict):
        return {}
    
    cleaned = {}
    
    # Clean name
    if 'name' in project and project['name']:
        cleaned['name'] = project['name'].strip()
    
    # Clean description
    if 'description' in project and project['description']:
        if isinstance(project['description'], list):
            cleaned['description'] = '\n'.join(str(item).strip() for item in project['description'] if str(item).strip())
        else:
            cleaned['description'] = str(project['description']).strip()
    
    # Clean technologies
    if 'technologies' in project and project['technologies']:
        if isinstance(project['technologies'], str):
            techs = [t.strip() for t in re.split(r'[,\s/;]', project['technologies']) if t.strip()]
        else:
            techs = []
            for tech in project['technologies']:
                if isinstance(tech, str):
                    techs.extend([t.strip() for t in re.split(r'[,\s/;]', tech) if t.strip()])
        cleaned['technologies'] = list(dict.fromkeys(techs))  # Remove duplicates while preserving order
    
    # Clean date
    if 'date' in project and project['date']:
        cleaned['date'] = str(project['date']).strip()
    
    # Clean URLs
    if 'url' in project and project['url']:
        cleaned['url'] = str(project['url']).strip()
    if 'urls' in project and project['urls']:
        if isinstance(project['urls'], (list, tuple)):
            cleaned['urls'] = [str(url).strip() for url in project['urls'] if str(url).strip()]
        else:
            cleaned['urls'] = [str(project['urls']).strip()]
    
    # Clean responsibilities
    if 'responsibilities' in project and project['responsibilities']:
        if isinstance(project['responsibilities'], str):
            cleaned['responsibilities'] = [item.strip() for item in project['responsibilities'].split('\n') if item.strip()]
        else:
            cleaned['responsibilities'] = [str(item).strip() for item in project['responsibilities'] if str(item).strip()]
    
    # Clean achievements
    if 'achievements' in project and project['achievements']:
        if isinstance(project['achievements'], str):
            cleaned['achievements'] = [item.strip() for item in project['achievements'].split('\n') if item.strip()]
        else:
            cleaned['achievements'] = [str(item).strip() for item in project['achievements'] if str(item).strip()]
    
    return cleaned


def extract_projects_section(text: str) -> list:
    """Extracts the Projects section from the resume text with advanced parsing.
    
    Args:
        text (str): The text content of the resume
        
    Returns:
        list: A list of dictionaries containing project information
    """
    if not text:
        return []
    
    print("\n=== Starting Project Extraction ===")
    print(f"Text length: {len(text)} characters")
    
    # Common section headers for projects - expanded list with more variations
    project_headers = [
        r'projects?',
        r'personal\s+projects?',
        r'academic\s+projects?',
        r'side\s+projects?',
        r'project\s+experience',
        r'selected\s+projects?',
        r'key\s+projects?',
        r'project\s+work',
        r'research\s+projects?',
        r'academic\s+work',
        r'projects?\s*&\s*research',
        r'projects?\s*[:;]',
        r'technical\s+projects?',
        r'projects?\s+experience',
        r'projects?\s*&\s*achievements?',
        r'projects?\s*&\s*activities',
        r'projects?\s*&\s*publications?',
        r'projects?\s*&\s*research',
        r'projects?\s*&\s*technical\s+skills',
        r'projects?\s*&\s*work\s+experience',
        r'project\s+portfolio',
        r'project\s+highlights',
        r'project\s+details',
        r'project\s+showcase',
        r'project\s+examples?',
        r'project\s+work\s+experience',
        r'project\s+involvement',
        r'project\s+participation',
        r'project\s+undertaken',
        r'project\s+highlights?',
        r'project\s+summary',
        r'project\s+details?',
        r'project\s+execution',
        r'project\s+implementation',
        r'project\s+deliverables?'
    ]
    
    # Try to find the projects section
    projects_section = None
    matched_header = None
    
    # First, try to find a dedicated projects section
    for header in project_headers:
        # Look for section header followed by content until next section
        pattern = rf'(?i)(?:^|\n)\s*{header}\s*[\n\-~=*_]*\s*\n(.*?)(?=\n\s*\n(?:[A-Z][A-Z\s]+\n|education|skills|work|experience|certifications|publications|volunteer|references|$|\n\s*[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s*[\n\-~=*_]+\s*\n))'
        match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
        if match:
            projects_section = match.group(1).strip()
            matched_header = header
            print(f"Found projects section with header: {header}")
            print(f"Section content (first 200 chars): {projects_section[:200]}...")
            break
    
    if not projects_section:
        print("No dedicated projects section found, will try to extract projects from full text")
        projects_section = text  # Fall back to full text if no section found
    
    # If no dedicated section found, try to find project-like content in the whole text
    if not projects_section:
        print("No dedicated projects section found, trying alternative extraction methods...")
        projects_section = text  # Use full text for pattern matching
    
    print(f"Projects section length: {len(projects_section)} characters")
    
    # More comprehensive project detection patterns with better grouping
    project_patterns = [
        # Project title followed by description (with optional technologies and date)
        r'(?i)(?:^|\n)(?P<name>[^\n:•\-–—]+?)\s*(?:\((?P<technologies>[^)]+)\))?\s*(?:(?P<date>\w+\s*\d{4}\s*[\-–—]\s*(?:\w+\s*\d{4}|Present|Current|Now|Present\)))?\s*[:\-–—]?\s*(?P<description>[^\n]+?)(?=\n\s*\n|$|\n\s*(?:[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s*[:\-–—]|$))',
        # Bullet points with project info
        r'(?i)(?:^|\n)[•\-*]\s*(?P<name>[^\n:•\-–—]+?)\s*[:\-–—]?\s*(?P<description>[^\n]+?)(?=\n|$)',
        # Project with date range
        r'(?i)(?:^|\n)(?P<name>[^\n(]+?)\s*(?:\((?P<technologies>[^)]+)\))?\s*(?P<date>\w+\s*\d{4}\s*[\-–—]\s*(?:\w+\s*\d{4}|Present|Current|Now|Present\)))?\s*[:\-–—]?\s*(?P<description>[^\n]+)',
        # Generic project indicators
        r'(?i)(?:project|developed|built|created|implemented|designed|constructed|programmed|coded|engineered)[^\n:•\-–—]*[\s:]*([^\n]+?)(?=\n\s*\n|$)'
        # Pattern 2: Just project name
        r'^(?P<name>[^\n]+?)$',
        # Pattern 3: Project Name: Description
        r'^(?P<name>[^\n:]+?):\s*(?P<description>.+?)(?=\n\s*\n|$)',
        # Pattern 4: • Project Name - Description
        r'^[•*\-]\s*(?P<name>[^\n\-–—]+?)(?:\s*[-–—]\s*(?P<description>[^\n]+))?$',
        # Pattern 5: 1. Project Name - Description
        r'^\d+[.)]\s*(?P<name>[^\n\-–—]+?)(?:\s*[-–—]\s*(?P<description>[^\n]+))?$'
    ]
    
    # Common date patterns for projects
    date_patterns = [
        r'(?i)(?:(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[\s,]*\d{4}|\d{1,2}[/\-\.]\d{1,2}[/\-\.]?(?:\d{2,4})?|(?:19|20)\d{2})',
        r'(?i)(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[\s,]*\d{4}\s*[–—]\s*(?:present|now|current|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[\s,]*\d{4}|\d{1,2}[/\-\.]\d{4})',
        r'\d{4}\s*[–—]\s*\d{4}'
    ]
    
    # Split into potential project blocks
    project_blocks = []
    
    # First try to split by common project delimiters
    split_patterns = [
        r'(?i)(?=\n\s*\n(?:[A-Z][A-Z\s]+\n|\d+\.\s|[-•*]\s|\b(?:project|role|technolog|date|tech|tools?|stack|description|responsibilities?)[:;]?\s|$))',
        r'(?i)(?=\n\s*\n|\n\s*(?=[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s*[\n\-~=*_]+\s*\n)|$)',
        r'(?i)(?=\n\s*[-•*]\s*)',
        r'(?i)(?=\n\s*\d+[.)]\s*)'
    ]
    
    # Try different split patterns until we get meaningful blocks
    for pattern in split_patterns:
        potential_blocks = re.split(pattern, projects_section)
        potential_blocks = [b.strip() for b in potential_blocks if b.strip()]
        
        if len(potential_blocks) > 1:  # If we got multiple blocks, use this split
            project_blocks = potential_blocks
            break
    
    # If no blocks found with the above method, try a simpler approach
    if not project_blocks:
        project_blocks = [b.strip() for b in re.split(r'\n\s*\n+', projects_section) if b.strip() and len(b.split()) >= 3]
    
    # Filter out blocks that are definitely not projects
    filtered_blocks = []
    min_project_length = 5  # Reduced minimum length to catch more potential projects
    
    for block in project_blocks:
        block = block.strip()
        if not block or len(block) < min_project_length:
            continue
            
        # Check for common non-project content
        is_education = bool(re.search(r'\b(?:education|university|college|school|degree|bachelor|master|phd|gpa|grade|coursework|studies)\b', block, re.IGNORECASE))
        is_contact = bool(re.search(r'\b(?:email|phone|linkedin|github|portfolio|website|contact|address)\b', block, re.IGNORECASE))
        
        if is_education or is_contact:
            continue
            
        # Check if this looks like a project (has some project-like keywords or technical terms)
        project_keywords = [
            'project', 'developed', 'built', 'created', 'implemented', 'designed', 
            'technolog', 'tools?', 'stack', 'framework', 'library', 'api', 'app', 
            'application', 'website', 'web app', 'mobile app', 'software', 'system',
            'researched', 'engineered', 'programmed', 'coded', 'developed', 'designed',
            'architected', 'deployed', 'launched', 'delivered', 'contributed', 'collaborated'
        ]
        
        has_project_keyword = any(re.search(rf'\b{kw}\b', block, re.IGNORECASE) for kw in project_keywords)
        has_tech_terms = bool(re.search(
            r'\b(?:python|java|c\+\+|javascript|typescript|react|angular|vue|node\.?js|' 
            r'sql|mysql|postgresql|mongodb|html|css|sass|scss|django|flask|fastapi|spring|' 
            r'machine[\s-]?learning|data[\s-]?scien|ai\b|artificial[\s-]?intelligence|' 
            r'database|server|client|front[\s-]?end|back[\s-]?end|full[\s-]?stack|' 
            r'docker|kubernetes|aws|azure|gcp|cloud|devops|ci\/?cd|git|github|gitlab|bitbucket|' 
            r'rest\s?api|graphql|grpc|microservices|api[\s-]?gateway|' 
            r'react\s?native|flutter|ios|android|mobile|responsive\s?design)'
            r'(?:\s*[\/\|,]?\s*[\w\s+]*)*', 
            block, re.IGNORECASE
        ))
        
        # Check for project-like structure
        has_project_structure = (
            # Has a title/name followed by description
            (len(block.split('\n')) > 1) or
            # Contains bullet points or numbered lists
            bool(re.search(r'^[\s\u2022\u2023\u25E6\u25AA\u25AB\u25A0\-*]\s*\w+', block, re.MULTILINE)) or
            # Contains common project section headers
            bool(re.search(r'(?i)(?:technolog|tools?|stack|features?|responsibilit|achievements?|results?)[:\n]', block))
        )
        
        # Check for meaningful content
        has_meaningful_content = (
            any(char.isdigit() for char in block) or  # Contains numbers
            any(word.istitle() for word in block.split() if len(word) > 2) or  # Has proper nouns
            len([w for w in block.split() if len(w) > 3]) > 1  # Has several longer words
        )
        
        # Be more inclusive in what we consider a project
        if (has_project_keyword or has_tech_terms or has_project_structure) and has_meaningful_content:
            filtered_blocks.append(block)
        elif has_meaningful_content and len(block.split()) > 5:  # If it's substantial text, include it
            filtered_blocks.append(block)
    
    # Only use filtered blocks if we found valid projects
    if not filtered_blocks:
        return []  # Return empty list if no valid projects found
        
    # Only proceed with filtered blocks that look like actual projects
    project_blocks = filtered_blocks
    
    projects = []
    
    for block in project_blocks:
        block = block.strip()
        if not block or len(block.split()) < 3:  # Skip very short blocks
            continue
            
        project = {}
        lines = [line.strip() for line in block.split('\n') if line.strip()]
        
        # First, try to extract structured information from the block
        self_contained_project = extract_self_contained_project(block)
        if self_contained_project:
            projects.append(self_contained_project)
            continue
        
        # If no structured format found, try line-by-line parsing
        if lines:
            # First line is typically the project name/title
            title_line = lines[0]
            
            # Try to extract project name, technologies, and date from the title line
            project_info = parse_project_title_line(title_line)
            project.update(project_info)
            
            # The remaining lines are the description
            if len(lines) > 1:
                description_lines = []
                current_section = None
                
                for line in lines[1:]:
                    # Check for section headers
                    section_match = re.match(r'^(?:\s*[-•*]?\s*)?(Technologies?|Tools?|Stack|Features?|Responsibilities?|Achievements?|Results?|Description|Details?|Links?|URLs?)\s*[:\-]?\s*$', 
                                          line, re.IGNORECASE)
                    if section_match:
                        current_section = section_match.group(1).lower()
                        continue
                        
                    if not line.strip():
                        continue
                        
                    # Clean up bullet points and numbering
                    line = re.sub(r'^[\s\u2022\u2023\u25E6\u25AA\u25AB\u25A0\-*]\s*', '', line)
                    line = re.sub(r'^\d+[.)]\s*', '', line)
                    
                    if current_section:
                        if current_section in ['technologies', 'technology', 'tools', 'tool', 'stack']:
                            if 'technologies' not in project:
                                project['technologies'] = []
                            techs = [t.strip() for t in re.split(r'[,\s/;]', line) if t.strip()]
                            project['technologies'].extend(techs)
                        elif current_section in ['responsibilities', 'responsibility']:
                            if 'responsibilities' not in project:
                                project['responsibilities'] = []
                            project['responsibilities'].append(line.strip())
                        elif current_section in ['achievements', 'results']:
                            if 'achievements' not in project:
                                project['achievements'] = []
                            project['achievements'].append(line.strip())
                        elif current_section in ['links', 'url', 'urls']:
                            urls = re.findall(r'https?://[^\s\n)]+', line)
                            if urls:
                                if 'urls' not in project:
                                    project['urls'] = []
                                project['urls'].extend(urls)
                    else:
                        description_lines.append(line.strip())
                
                # Join the description lines if we didn't categorize them
                if description_lines:
                    project['description'] = '\n'.join(description_lines)
        
        # Extract additional metadata if not already found
        if 'technologies' not in project:
            tech_matches = re.findall(r'\b(?:Technologies?|Tools?|Stack|Built with)[:\s]+([^\n]+)', block, re.IGNORECASE)
            if tech_matches:
                technologies = []
                for match in tech_matches:
                    techs = [t.strip() for t in re.split(r'[,\s/;]', match) if t.strip()]
                    technologies.extend(techs)
                if technologies:
                    project['technologies'] = technologies
            else:
                # Fallback: Look for technologies in parentheses or brackets
                tech_matches = re.findall(r'[\(\[](.*?)[\)\]]', block)
                if tech_matches:
                    technologies = []
                    for match in tech_matches:
                        techs = [t.strip() for t in re.split(r'[,\s/;]', match) if t.strip() and len(t.strip()) > 1]
                        technologies.extend(techs)
                    if technologies:
                        project['technologies'] = technologies
        
        # Extract date if not already found
        if 'date' not in project:
            for pattern in date_patterns:
                date_match = re.search(pattern, block, re.IGNORECASE)
                if date_match:
                    project['date'] = date_match.group(0).strip()
                    break
        
        # Extract URL if not already found
        if 'url' not in project and 'urls' not in project:
            urls = re.findall(r'https?://[^\s\n)]+', block)
            if urls:
                if len(urls) == 1:
                    project['url'] = urls[0]
                else:
                    project['urls'] = urls
        
        # Clean up the project data
        project = clean_project_data(project)
        
        # Only add if we have enough information
        if project.get('name') or project.get('description') or project.get('technologies'):
            projects.append(project)
    
    # Define the sort key function inside the extract_projects_section function
    def get_project_sort_key(proj):
        if 'date' in proj and proj['date']:
            year_match = re.search(r'\b(20\d{2}|19\d{2})\b', proj['date'])
            if year_match:
                return (int(year_match.group(1)), proj['name'].lower())
        return (0, proj['name'].lower())
    
    # Sort projects by date (most recent first) and then by name
    projects.sort(key=get_project_sort_key, reverse=True)
    
    return projects


if __name__ == '__main__':
    print("Please use test_pdf_parser.py for testing the PDF parser functionality.")
    print("Usage: python test_pdf_parser.py <path_to_pdf>")
