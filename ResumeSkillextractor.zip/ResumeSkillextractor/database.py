import sqlite3
import json
from datetime import datetime
from pathlib import Path

# Ensure the database directory exists
DB_PATH = Path('extracted_data/resume_database.db')
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

def get_db_connection():
    """Create and return a database connection"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize the database with required tables"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Create resumes table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS resumes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT NOT NULL,
        name TEXT,
        email TEXT,
        phone TEXT,
        raw_text TEXT,
        extracted_data TEXT,
        processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    
    # Create skills table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS skills (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        resume_id INTEGER,
        skill_type TEXT,
        skill_name TEXT,
        source_section TEXT,
        FOREIGN KEY (resume_id) REFERENCES resumes (id)
    )''')
    
    conn.commit()
    conn.close()

def save_resume_data(filename, name, email, phone, raw_text, extracted_data):
    """Save resume data to the database with current local timestamp"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Get current local datetime
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # Convert extracted_data to JSON string if it's a dictionary
        if isinstance(extracted_data, dict):
            extracted_data_str = json.dumps(extracted_data)
        else:
            extracted_data_str = extracted_data or ''
        
        # Insert the resume data with explicit timestamp
        cursor.execute('''
            INSERT INTO resumes (filename, name, email, phone, raw_text, extracted_data, processed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (filename, name, email, phone, raw_text, extracted_data_str, current_time))
        
        # Get the ID of the inserted resume
        resume_id = cursor.lastrowid
        
        # Save skills if they exist in extracted_data
        if isinstance(extracted_data, dict):
            # Save general skills
            for skill in extracted_data.get('skills', []):
                cursor.execute('''
                    INSERT INTO skills (resume_id, skill_name, skill_type, source_section)
                    VALUES (?, ?, ?, ?)
                ''', (resume_id, skill, 'general', 'general'))
            
            # Save skills from work experience
            for skill in extracted_data.get('skills_from_work_experience', []):
                cursor.execute('''
                    INSERT INTO skills (resume_id, skill_name, skill_type, source_section)
                    VALUES (?, ?, ?, ?)
                ''', (resume_id, skill, 'work_experience', 'work_experience'))
            
            # Save skills from projects
            for skill in extracted_data.get('skills_from_projects', []):
                cursor.execute('''
                    INSERT INTO skills (resume_id, skill_name, skill_type, source_section)
                    VALUES (?, ?, ?, ?)
                ''', (resume_id, skill, 'project', 'projects'))
        
        conn.commit()
        return resume_id
    except Exception as e:
        conn.rollback()
        print(f"Error saving resume data: {e}")
        raise
    finally:
        conn.close()

def get_all_resumes():
    """Retrieve all stored resumes with basic info"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
    SELECT id, filename, name, email, phone, processed_at 
    FROM resumes 
    ORDER BY processed_at DESC
    ''')
    
    resumes = []
    for row in cursor.fetchall():
        resume = dict(row)
        # Ensure processed_at is a datetime object
        if isinstance(resume['processed_at'], str):
            from datetime import datetime
            try:
                resume['processed_at'] = datetime.strptime(resume['processed_at'], '%Y-%m-%d %H:%M:%S')
            except (ValueError, TypeError):
                # If parsing fails, use current time
                resume['processed_at'] = datetime.now()
        resumes.append(resume)
        
    conn.close()
    return resumes

def get_resume_details(resume_id):
    """Get detailed information for a specific resume"""
    conn = get_db_connection()
    try:
        # Get basic resume info
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM resumes WHERE id = ?', (resume_id,))
        resume = cursor.fetchone()
        
        if not resume:
            return None
            
        # Convert resume row to dict
        resume_dict = dict(resume)
        
        # Parse the extracted_data if it exists
        if resume_dict.get('extracted_data'):
            try:
                extracted_data = json.loads(resume_dict['extracted_data'])
                resume_dict['extracted_data'] = extracted_data
            except json.JSONDecodeError:
                resume_dict['extracted_data'] = {}
        else:
            resume_dict['extracted_data'] = {}
        
        # Get all unique skills from the skills table
        cursor.execute('''
            SELECT DISTINCT skill_name 
            FROM skills 
            WHERE resume_id = ?
            ORDER BY skill_name
        ''', (resume_id,))
        
        # Combine all skills into a single list
        all_skills = [skill['skill_name'] for skill in cursor.fetchall()]
        
        # Update extracted_data with combined skills
        if 'extracted_data' not in resume_dict:
            resume_dict['extracted_data'] = {}
            
        # Only use the main skills field, don't include the separated skill lists
        resume_dict['extracted_data']['skills'] = all_skills
        
        return {
            'resume': resume_dict,
            'skills': all_skills
        }
    except Exception as e:
        print(f"Error getting resume details: {e}")
        return None
    finally:
        conn.close()

# Initialize the database when this module is imported
init_db()
