import os
import json
import re
from flask import Flask, render_template, request, redirect, url_for, flash, get_flashed_messages, jsonify, send_from_directory, json
from werkzeug.utils import secure_filename
from pdf_parser import (
    extract_text_from_pdf, extract_skills_from_text, 
    extract_email, extract_phone, extract_name, extract_work_experience, extract_projects_section, extract_skills_nlp
)
from database import save_resume_data, get_all_resumes, get_resume_details, get_db_connection

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf'}

app = Flask(__name__, template_folder='templates')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['SECRET_KEY'] = 'supersecretkey' # Needed for flash messages

# Ensure the upload folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Ensure other necessary folders exist as per README
if not os.path.exists('static/css'):
    os.makedirs('static/css')
if not os.path.exists('static/js'):
    os.makedirs('static/js')
if not os.path.exists('extracted_data'):
    os.makedirs('extracted_data')

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET'])
def index():
    # Get all stored resumes for the dashboard
    resumes = get_all_resumes()
    
    # Get resume_id from query parameters if viewing a specific resume
    resume_id = request.args.get('resume_id')
    
    if resume_id and resume_id.isdigit():
        try:
            resume_details = get_resume_details(int(resume_id))
            # If we're viewing a specific resume, show its data
            if resume_details and 'resume' in resume_details:
                extracted_data = resume_details['resume'].get('extracted_data', {})
                if isinstance(extracted_data, str):
                    extracted_data = json.loads(extracted_data)
                return render_template('index.html', 
                                    message=None,
                                    raw_text=resume_details['resume'].get('raw_text', ''), 
                                    extracted_data=extracted_data,
                                    resumes=resumes,
                                    current_resume_id=int(resume_id))
        except Exception as e:
            flash(f'Error loading resume: {str(e)}', 'error')
    
    # Default view - show the form and list of resumes
    return render_template('index.html', 
                         message=None, 
                         raw_text=None, 
                         extracted_data=None,
                         resumes=resumes,
                         current_resume_id=None)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/view_resume/<int:resume_id>')
def view_resume(resume_id):
    try:
        resume_details = get_resume_details(resume_id)
        if resume_details and 'resume' in resume_details:
            extracted_data = resume_details['resume'].get('extracted_data', {})
            if isinstance(extracted_data, str):
                extracted_data = json.loads(extracted_data)
                    
            # If work experience is missing but we have raw text, try to extract it
            if 'work_experience' not in extracted_data and resume_details['resume'].get('raw_text'):
                work_exp = extract_work_experience(resume_details['resume']['raw_text'])
                if work_exp:
                    extracted_data['work_experience'] = work_exp
            
            # Ensure projects is in the correct format
            if 'projects' not in extracted_data or not extracted_data['projects']:
                # If no projects found, try to extract them
                projects = extract_projects_section(resume_details['resume'].get('raw_text', ''))
                if projects:
                    extracted_data['projects'] = projects
                else:
                    extracted_data['projects'] = []
            elif isinstance(extracted_data['projects'], str):
                # If projects is a string, convert it to a list
                extracted_data['projects'] = [extracted_data['projects']]
            
            # Ensure work_experience is a list
            if 'work_experience' not in extracted_data or not extracted_data['work_experience']:
                extracted_data['work_experience'] = []
            elif isinstance(extracted_data['work_experience'], str):
                extracted_data['work_experience'] = [extracted_data['work_experience']]
                
            # Ensure skills is a list
            if 'skills' not in extracted_data or not extracted_data['skills']:
                extracted_data['skills'] = []
            elif isinstance(extracted_data['skills'], str):
                extracted_data['skills'] = [extracted_data['skills']]
            
            return render_template('index.html',
                                message=None,
                                raw_text=resume_details['resume'].get('raw_text', ''),
                                extracted_data=extracted_data,
                                resumes=get_all_resumes(),
                                current_resume_id=resume_id)
    except Exception as e:
        flash(f'Error loading resume: {str(e)}', 'error')
    return redirect(url_for('index'))

@app.route('/delete_resume/<int:resume_id>', methods=['POST'])
def delete_resume(resume_id):
    try:
        # Get resume details
        resume = get_resume_details(resume_id)
        if not resume or 'resume' not in resume:
            return jsonify({'success': False, 'message': 'Resume not found'}), 404
        
        # Delete the file if it exists
        filename = resume['resume'].get('filename')
        if filename:
            try:
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                if os.path.exists(filepath):
                    os.remove(filepath)
            except Exception as e:
                print(f"Error deleting file: {e}")
        
        # Delete from database
        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM skills WHERE resume_id = ?', (resume_id,))
            cursor.execute('DELETE FROM resumes WHERE id = ?', (resume_id,))
            conn.commit()
            return jsonify({'success': True})
        except Exception as e:
            conn.rollback()
            return jsonify({'success': False, 'message': str(e)}), 500
        finally:
            conn.close()
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'GET':
        return redirect(url_for('index'))
        
    if 'resume' not in request.files:
        flash('No file part', 'error')
        return redirect(request.url)
    
    file = request.files['resume']
    if file.filename == '':
        flash('No selected file', 'error')
        return redirect(request.url)
    
    if not file or not allowed_file(file.filename):
        flash('Invalid file type. Please upload a PDF file.', 'error')
        return redirect(request.url)
    
    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    
    try:
        # Ensure unique filename
        counter = 1
        while os.path.exists(filepath):
            name, ext = os.path.splitext(filename)
            filename = f"{name}_{counter}{ext}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            counter += 1
        
        # Save the file
        file.save(filepath)
        print(f"\n=== Processing file: {filename} ===")
        
        # Extract text from PDF
        print("Extracting text from PDF...")
        extracted_text = extract_text_from_pdf(filepath)
        
        if not extracted_text or len(extracted_text.strip()) < 50:  # Arbitrary minimum length
            os.remove(filepath)  # Clean up the file
            flash('Could not extract meaningful text from the PDF. The file might be scanned or corrupted.', 'error')
            return redirect(request.url)
        
        # Extract information
        print("Extracting information...")
        name = extract_name(extracted_text) or 'Not Found'
        email = extract_email(extracted_text) or 'Not Found'
        phone = extract_phone(extracted_text) or 'Not Found'
        skills = extract_skills_from_text(extracted_text)
        work_experience = extract_work_experience(extracted_text)
        
        # Extract projects with enhanced parsing
        projects = extract_projects_section(extracted_text)
        
        # If no projects found, try to extract from other sections
        if not projects or (isinstance(projects, list) and len(projects) == 0):
            print("No projects found in dedicated section, trying alternative extraction...")
            # Look for project-like content in the whole text
            project_patterns = [
                r'(?i)(?:project|developed|built|created|implemented|designed)[\s\S]+?(?=\n\s*\n|$)',
                r'(?i)(?:^|\n)([A-Z][^\n:•\-–—]+?)\s*[\-–—]?\s*([^\n]+?)(?=\n\s*\n|$|\n\s*(?:[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s*[\-–—]|$))',
                r'(?i)(?:^|\n)([A-Z][^\n(]+?)\s*(?:\(([^)]+)\))?\s*:\s*([^\n]+)',
                r'(?i)(?:^|\n)[•\-*]\s*([^\n:•\-–—]+?)\s*[\-–—]?\s*([^\n]+?)(?=\n|$)'
            ]
            
            all_matches = []
            for pattern in project_patterns:
                matches = re.finditer(pattern, extracted_text, re.DOTALL | re.IGNORECASE)
                all_matches.extend([m.group(0).strip() for m in matches if m.group(0).strip()])
            
            if all_matches:
                # Remove duplicates while preserving order
                seen = set()
                projects = []
                for project_text in all_matches:
                    if project_text and project_text not in seen:
                        seen.add(project_text)
                        projects.append(project_text)
        
        # Ensure projects is a list
        if isinstance(projects, str):
            projects = [projects]
        elif projects is None:
            projects = []
        
        # Prepare extracted data
        extracted_data = {
            'name': name,
            'email': email,
            'phone': phone,
            'skills': skills,
            'work_experience': work_experience if work_experience else [],
            'projects': projects,
            'filename': filename
        }
        
        # Debug output
        print(f"Name: {name}")
        print(f"Email: {email}")
        print(f"Phone: {phone}")
        print(f"Skills: {skills}")
        print(f"Work Experience: {len(work_experience)} entries")
        print(f"Projects: {len(projects)} entries")
        
        # Save to database
        resume_id = save_resume_data(
            filename=filename,
            name=name,
            email=email,
            phone=phone,
            raw_text=extracted_text,
            extracted_data=extracted_data
        )
        
        flash(f'Successfully processed and saved "{filename}"', 'success')
        return redirect(url_for('view_resume', resume_id=resume_id))
        
    except Exception as e:
        # Clean up file if there was an error
        if os.path.exists(filepath):
            os.remove(filepath)
        flash(f'Error processing file: {str(e)}', 'error')
        return redirect(request.url)

@app.errorhandler(404)
def not_found_error(error):
    return render_template('error.html', error=error), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('error.html', error=str(error)), 500

@app.route('/api/resumes/search')
def search_resumes():
    """Search resumes by skill"""
    skill = request.args.get('skill', '').strip().lower()
    if not skill:
        return jsonify({'error': 'No skill provided'}), 400
    
    conn = get_db_connection()
    try:
        # Search in both skills table and raw text
        cursor = conn.cursor()
        
        # First, find resume IDs that have the skill in the skills table
        cursor.execute('''
            SELECT DISTINCT r.* 
            FROM resumes r
            LEFT JOIN skills s ON r.id = s.resume_id
            WHERE LOWER(s.skill_name) LIKE ?
            OR LOWER(r.raw_text) LIKE ?
            OR LOWER(r.extracted_data) LIKE ?
        ''', (f'%{skill}%', f'%{skill}%', f'%{skill}%'))
        
        resumes = []
        for row in cursor.fetchall():
            resume = dict(row)
            # Convert datetime to string if it's a datetime object
            if hasattr(resume['processed_at'], 'isoformat'):
                resume['processed_at'] = resume['processed_at'].isoformat()
            resumes.append(resume)
            
        return jsonify(resumes)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

if __name__ == '__main__':
    # Ensure the upload folder exists
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    app.run(debug=True)
